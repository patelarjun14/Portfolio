This dataset was compiled using data scraped from Twitter (using twitter Python API)

All tweets are pulled from the week of November 1st to November 8th 2018. Only commas and newline characters have been removed from the tweets; all other data preprocessing has been left to the user.

Data Sets (Keyword used to search Tweets):
- america
- computers
- facebook
- food
- football
- nature
- president
- thanksgiving
- twitter
- winter